package com.example.mailmeapp;
public class EmailDetails {

    private int id;
    private String sender;
    private String title;
    private String summary;
    private String time;

    public EmailDetails(String sender, String title, String summary, String time) {
        this.sender = sender;
        this.title = title;
        this.summary = summary;
        this.time = time;
    }

    public String getSender() {
        return sender;
    }

    public String getTitle() {
        return title;
    }

    public String getSummary() {
        return summary;
    }

    public String getTime() {
        return time;
    }

    public int getId(){return id; }

    public void setId(int id){this.id = id; }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public void setTime(String time) {
        this.time = time;
    }
}