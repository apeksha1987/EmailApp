package com.example.mailmeapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class DraftsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        RecyclerView emailList = (RecyclerView) inflater.inflate(R.layout.fragment_inbox, container, false);
        List<EmailDetails> emails = new ArrayList<>();

        EmailDetails email = new EmailDetails("Sam", "Weekend plans",
                "Let's go CNE. We will do some barbecue and have soo much fun", "10:42am");
        emails.add(email);
        email= new EmailDetails("Facebook", "Apeksha, you have 1 new notification",
                "A lot has happened on Facebook since",
                "16:04pm");
        emails.add(email);
        email = new EmailDetails("Google+", "Top suggested Google+ pages for you",
                "Increase your storage space",
                "18:44pm");
        emails.add(email);
        email = new EmailDetails("Twitter", "Follow T-Mobile, Samsung Mobile U",
                "Apeksha, some people you may know",
                "20:04pm");
        emails.add(email);
        email = new EmailDetails("Pinterest Weekly", "Pins you’ll love!",
                "Have you seen these Pins yet? Pinterest",
                "09:04am");
        emails.add(email);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        emailList.setLayoutManager(layoutManager);
        emailList.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));
        RecyclerAdapter adapter = new RecyclerAdapter(emails, getActivity());
        emailList.setAdapter(adapter);
        return emailList;
        //return inflater.inflate(R.layout.fragment_inbox, container, false);
    }
}
