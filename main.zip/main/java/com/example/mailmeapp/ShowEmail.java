package com.example.mailmeapp;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ShowEmail extends AppCompatActivity {

    TextView icon;
    TextView sender;
    TextView title;
    TextView details;
    TextView time;
    ImageView Favorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_email);

        icon = findViewById(R.id.icon);
        sender = findViewById(R.id.sender);
        title = findViewById(R.id.title);
        details = findViewById(R.id.details);
        time = findViewById(R.id.time);
        Favorite = findViewById(R.id.ivFavorite);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            icon.setText(bundle.getString("icon"));
            ((GradientDrawable) icon.getBackground()).setColor(bundle.getInt("coloricon"));
            sender.setText(bundle.getString("sender"));
            title.setText(bundle.getString("title"));
            details.setText(bundle.getString("details"));
            time.setText(bundle.getString("time"));
        }

    }
}
