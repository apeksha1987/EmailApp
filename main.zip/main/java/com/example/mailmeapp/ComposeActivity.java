package com.example.mailmeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ComposeActivity extends AppCompatActivity {
    EditText edit_text_to;
    EditText edit_text_subject;
    EditText edit_text_message;
    public static final String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.compose);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("@string/compose");
    }
    public void sendEmail(View v){
        edit_text_to = (EditText) findViewById(R.id.edit_text_to);
        edit_text_subject = (EditText) findViewById(R.id.edit_text_subject);
        edit_text_message = (EditText) findViewById(R.id.edit_text_message);
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        String date = df.format(new Date());
        EmailDetails email = new EmailDetails(edit_text_to.getText().toString().trim(), edit_text_subject.getText().toString().trim(),
                edit_text_message.getText().toString().trim(),date);
        //addEmail to database.

    }
}
